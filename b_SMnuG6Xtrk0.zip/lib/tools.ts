import {
  Calculator,
  Percent,
  TrendingUp,
  DollarSign,
  Calendar,
  Scale,
  FileText,
  Zap,
  PiggyBank,
  CreditCard,
  Building2,
  Clock,
  Ruler,
  Thermometer,
  Binary,
  Hash,
  type LucideIcon,
} from "lucide-react";

export interface Tool {
  slug: string;
  title: string;
  description: string;
  shortDescription: string;
  icon: LucideIcon;
  category: string;
  categorySlug: string;
  keywords: string[];
}

export interface Category {
  slug: string;
  name: string;
  description: string;
  icon: LucideIcon;
}

export const categories: Category[] = [
  {
    slug: "finance",
    name: "Finance Calculators",
    description: "EMI, loan, interest, and tax calculators for smart financial planning",
    icon: Calculator,
  },
  {
    slug: "investment",
    name: "Investment Tools",
    description: "SIP, mutual fund, and returns calculators for wealth building",
    icon: TrendingUp,
  },
  {
    slug: "converters",
    name: "Converters",
    description: "Currency, unit, and measurement conversion tools",
    icon: Scale,
  },
  {
    slug: "utilities",
    name: "Everyday Utilities",
    description: "Date, time, age, and everyday calculation tools",
    icon: Clock,
  },
];

export const tools: Tool[] = [
  // Finance Calculators
  {
    slug: "emi-calculator",
    title: "EMI Calculator",
    description: "Calculate your monthly EMI for home loans, car loans, and personal loans. Get a detailed breakdown of principal, interest, and total payable amount with our free EMI calculator.",
    shortDescription: "Calculate monthly loan installments instantly",
    icon: Calculator,
    category: "Finance Calculators",
    categorySlug: "finance",
    keywords: ["emi", "loan", "home loan", "car loan", "personal loan", "monthly installment"],
  },
  {
    slug: "gst-calculator",
    title: "GST Calculator",
    description: "Calculate GST amount and total price with our free GST calculator. Supports all GST slabs - 5%, 12%, 18%, and 28%. Perfect for businesses and individuals.",
    shortDescription: "Compute GST amounts for all tax slabs",
    icon: Percent,
    category: "Finance Calculators",
    categorySlug: "finance",
    keywords: ["gst", "tax", "goods and services tax", "business", "invoice"],
  },
  {
    slug: "income-tax-calculator",
    title: "Income Tax Calculator",
    description: "Calculate your income tax under both old and new tax regimes. Compare tax liability, deductions, and find the best regime for your income with our free tax calculator.",
    shortDescription: "Estimate tax under old and new regimes",
    icon: FileText,
    category: "Finance Calculators",
    categorySlug: "finance",
    keywords: ["income tax", "tax calculator", "old regime", "new regime", "deductions"],
  },
  {
    slug: "loan-calculator",
    title: "Loan Calculator",
    description: "Calculate loan EMI, total interest, and repayment schedule for any loan amount and tenure. Works for all types of loans including home, car, and personal loans.",
    shortDescription: "Get complete loan repayment details",
    icon: CreditCard,
    category: "Finance Calculators",
    categorySlug: "finance",
    keywords: ["loan", "emi", "interest", "repayment", "schedule"],
  },
  {
    slug: "fd-calculator",
    title: "FD Calculator",
    description: "Calculate fixed deposit maturity amount and interest earned. Compare FD returns across different tenures and interest rates with our free FD calculator.",
    shortDescription: "Calculate FD maturity and interest",
    icon: Building2,
    category: "Finance Calculators",
    categorySlug: "finance",
    keywords: ["fd", "fixed deposit", "maturity", "interest", "bank"],
  },
  // Investment Tools
  {
    slug: "sip-calculator",
    title: "SIP Calculator",
    description: "Calculate your SIP returns and wealth accumulation over time. Plan your mutual fund investments with projected returns using our free SIP calculator.",
    shortDescription: "Plan mutual fund investments",
    icon: TrendingUp,
    category: "Investment Tools",
    categorySlug: "investment",
    keywords: ["sip", "mutual fund", "investment", "returns", "wealth"],
  },
  {
    slug: "ppf-calculator",
    title: "PPF Calculator",
    description: "Calculate PPF maturity amount with yearly contributions. Plan your Public Provident Fund investments and see projected returns over 15 years.",
    shortDescription: "Plan PPF investments and returns",
    icon: PiggyBank,
    category: "Investment Tools",
    categorySlug: "investment",
    keywords: ["ppf", "public provident fund", "savings", "government", "investment"],
  },
  {
    slug: "compound-interest-calculator",
    title: "Compound Interest Calculator",
    description: "Calculate compound interest on your investments. See how your money grows with different compounding frequencies - daily, monthly, quarterly, or yearly.",
    shortDescription: "See how your money grows over time",
    icon: TrendingUp,
    category: "Investment Tools",
    categorySlug: "investment",
    keywords: ["compound interest", "investment", "growth", "returns", "compounding"],
  },
  // Converters
  {
    slug: "currency-converter",
    title: "Currency Converter",
    description: "Convert between world currencies with live exchange rates. Supports INR, USD, EUR, GBP, and 150+ currencies. Free real-time currency converter.",
    shortDescription: "Convert currencies with live rates",
    icon: DollarSign,
    category: "Converters",
    categorySlug: "converters",
    keywords: ["currency", "exchange rate", "inr", "usd", "eur", "forex"],
  },
  {
    slug: "unit-converter",
    title: "Unit Converter",
    description: "Convert between units of length, weight, volume, area, and more. Supports metric, imperial, and Indian measurement systems.",
    shortDescription: "Convert length, weight, volume, and more",
    icon: Scale,
    category: "Converters",
    categorySlug: "converters",
    keywords: ["unit", "convert", "length", "weight", "volume", "measurement"],
  },
  {
    slug: "length-converter",
    title: "Length Converter",
    description: "Convert between meters, feet, inches, centimeters, kilometers, and miles. Free length and distance converter with instant results.",
    shortDescription: "Convert meters, feet, inches, and more",
    icon: Ruler,
    category: "Converters",
    categorySlug: "converters",
    keywords: ["length", "distance", "meter", "feet", "inches", "kilometer"],
  },
  {
    slug: "temperature-converter",
    title: "Temperature Converter",
    description: "Convert between Celsius, Fahrenheit, and Kelvin instantly. Free temperature converter with formula explanations.",
    shortDescription: "Convert Celsius, Fahrenheit, Kelvin",
    icon: Thermometer,
    category: "Converters",
    categorySlug: "converters",
    keywords: ["temperature", "celsius", "fahrenheit", "kelvin", "convert"],
  },
  // Utilities
  {
    slug: "age-calculator",
    title: "Age Calculator",
    description: "Calculate your exact age in years, months, and days from your date of birth. Find out how many days until your next birthday.",
    shortDescription: "Calculate exact age from birth date",
    icon: Calendar,
    category: "Everyday Utilities",
    categorySlug: "utilities",
    keywords: ["age", "birthday", "date of birth", "years", "months", "days"],
  },
  {
    slug: "percentage-calculator",
    title: "Percentage Calculator",
    description: "Calculate percentages, percentage change, and percentage difference. Find what percent one number is of another instantly.",
    shortDescription: "Calculate percentages and changes",
    icon: Hash,
    category: "Everyday Utilities",
    categorySlug: "utilities",
    keywords: ["percentage", "percent", "calculate", "change", "difference"],
  },
  {
    slug: "electricity-bill-calculator",
    title: "Electricity Bill Calculator",
    description: "Calculate your electricity bill based on units consumed and tariff rates. Estimate monthly electricity costs for your home or business.",
    shortDescription: "Estimate electricity costs",
    icon: Zap,
    category: "Everyday Utilities",
    categorySlug: "utilities",
    keywords: ["electricity", "bill", "units", "tariff", "power", "consumption"],
  },
  {
    slug: "binary-converter",
    title: "Binary Converter",
    description: "Convert between binary, decimal, hexadecimal, and octal number systems. Free number base converter for programmers and students.",
    shortDescription: "Convert between number systems",
    icon: Binary,
    category: "Everyday Utilities",
    categorySlug: "utilities",
    keywords: ["binary", "decimal", "hexadecimal", "octal", "convert", "number"],
  },
];

export function getToolsByCategory(categorySlug: string): Tool[] {
  return tools.filter((tool) => tool.categorySlug === categorySlug);
}

export function getToolBySlug(slug: string): Tool | undefined {
  return tools.find((tool) => tool.slug === slug);
}

export function getCategoryBySlug(slug: string): Category | undefined {
  return categories.find((category) => category.slug === slug);
}

export function getRelatedTools(currentSlug: string, limit = 4): Tool[] {
  const currentTool = getToolBySlug(currentSlug);
  if (!currentTool) return tools.slice(0, limit);
  
  const sameCategoryTools = tools.filter(
    (tool) => tool.categorySlug === currentTool.categorySlug && tool.slug !== currentSlug
  );
  
  if (sameCategoryTools.length >= limit) {
    return sameCategoryTools.slice(0, limit);
  }
  
  const otherTools = tools.filter(
    (tool) => tool.categorySlug !== currentTool.categorySlug
  );
  
  return [...sameCategoryTools, ...otherTools].slice(0, limit);
}
