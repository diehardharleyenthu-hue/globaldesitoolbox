import { Metadata } from "next";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { ToolCard } from "@/components/tool-card";
import { Breadcrumbs } from "@/components/breadcrumbs";
import { tools, categories } from "@/lib/tools";

export const metadata: Metadata = {
  title: "All Tools - Free Online Calculators | Global Desi Toolbox",
  description:
    "Browse all free online tools: EMI calculator, GST calculator, SIP calculator, currency converter, age calculator, and more.",
};

export default function AllToolsPage() {
  return (
    <>
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
        <Breadcrumbs items={[{ label: "All Tools" }]} />

        <section className="mb-8">
          <h1 className="text-2xl font-bold text-foreground md:text-3xl">
            All Tools
          </h1>
          <p className="mt-2 text-muted-foreground">
            {tools.length} free online calculators and utility tools
          </p>
        </section>

        {/* Ad-friendly spacing */}
        <div className="my-8" aria-hidden="true" />

        <div className="space-y-12">
          {categories.map((category) => {
            const categoryTools = tools.filter(
              (t) => t.categorySlug === category.slug
            );
            const Icon = category.icon;

            return (
              <section key={category.slug}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h2 className="text-lg font-semibold text-foreground">
                      {category.name}
                    </h2>
                    <p className="text-sm text-muted-foreground">
                      {categoryTools.length} tools
                    </p>
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {categoryTools.map((tool) => (
                    <ToolCard key={tool.slug} tool={tool} showCategory={false} />
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      </main>
      <Footer />
    </>
  );
}
