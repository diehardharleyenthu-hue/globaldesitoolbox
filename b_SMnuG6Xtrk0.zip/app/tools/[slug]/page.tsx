import { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { ToolCard } from "@/components/tool-card";
import { Breadcrumbs } from "@/components/breadcrumbs";
import {
  tools,
  getToolBySlug,
  getCategoryBySlug,
  getRelatedTools,
} from "@/lib/tools";

interface ToolPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  return tools.map((tool) => ({
    slug: tool.slug,
  }));
}

export async function generateMetadata({
  params,
}: ToolPageProps): Promise<Metadata> {
  const { slug } = await params;
  const tool = getToolBySlug(slug);

  if (!tool) {
    return { title: "Tool Not Found" };
  }

  return {
    title: `${tool.title} - Free Online Calculator | Global Desi Toolbox`,
    description: tool.description,
    keywords: tool.keywords,
    openGraph: {
      title: `${tool.title} - Global Desi Toolbox`,
      description: tool.description,
    },
  };
}

export default async function ToolPage({ params }: ToolPageProps) {
  const { slug } = await params;
  const tool = getToolBySlug(slug);

  if (!tool) {
    notFound();
  }

  const category = getCategoryBySlug(tool.categorySlug);
  const relatedTools = getRelatedTools(slug, 4);
  const Icon = tool.icon;

  return (
    <>
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
        <Breadcrumbs
          items={[
            { label: category?.name || "Tools", href: `/category/${tool.categorySlug}` },
            { label: tool.title },
          ]}
        />

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Content Area */}
          <div className="lg:col-span-2">
            <section className="mb-8">
              <div className="flex items-center gap-4 mb-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-foreground md:text-3xl">
                    {tool.title}
                  </h1>
                  <Link
                    href={`/category/${tool.categorySlug}`}
                    className="text-sm text-primary hover:underline"
                  >
                    {tool.category}
                  </Link>
                </div>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                {tool.description}
              </p>
            </section>

            {/* Calculator Placeholder */}
            <section className="rounded-lg border border-border bg-card p-6 md:p-8 mb-8">
              <div className="text-center py-12">
                <Icon className="h-16 w-16 text-primary/30 mx-auto mb-4" />
                <p className="text-muted-foreground">
                  {tool.title} interface will appear here
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  Calculator functionality coming soon
                </p>
              </div>
            </section>

            {/* Ad-friendly spacing */}
            <div className="my-8" aria-hidden="true" />

            {/* How to Use Section */}
            <section className="rounded-lg border border-border bg-card p-6 mb-8">
              <h2 className="text-lg font-semibold text-foreground mb-4">
                How to Use {tool.title}
              </h2>
              <ol className="list-decimal list-inside space-y-2 text-sm text-muted-foreground">
                <li>Enter the required values in the input fields above</li>
                <li>The calculator will automatically compute the results</li>
                <li>View the detailed breakdown of your calculation</li>
                <li>Use the results to make informed decisions</li>
              </ol>
            </section>

            {/* FAQ Section for SEO */}
            <section className="rounded-lg border border-border bg-card p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">
                Frequently Asked Questions
              </h2>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-foreground">
                    Is this {tool.title.toLowerCase()} free to use?
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Yes, this tool is completely free with no hidden charges or sign-up required.
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-foreground">
                    How accurate is the {tool.title.toLowerCase()}?
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Our calculator uses standard formulas and provides accurate results. 
                    However, for financial decisions, we recommend consulting a professional.
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-foreground">
                    Is my data saved or shared?
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    No, all calculations are performed in your browser. 
                    We do not store or share your data.
                  </p>
                </div>
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <aside className="lg:col-span-1">
            {/* Ad-friendly sidebar spacing */}
            <div className="sticky top-20">
              <div className="rounded-lg border border-border bg-card p-5 mb-6">
                <h3 className="text-sm font-semibold text-foreground mb-4">
                  Related Tools
                </h3>
                <div className="space-y-3">
                  {relatedTools.map((relatedTool) => {
                    const RelatedIcon = relatedTool.icon;
                    return (
                      <Link
                        key={relatedTool.slug}
                        href={`/tools/${relatedTool.slug}`}
                        className="flex items-center gap-3 p-2 rounded-md hover:bg-secondary"
                      >
                        <div className="flex h-8 w-8 items-center justify-center rounded bg-primary/10">
                          <RelatedIcon className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">
                            {relatedTool.title}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {relatedTool.category}
                          </p>
                        </div>
                      </Link>
                    );
                  })}
                </div>
              </div>

              {/* Ad-friendly space in sidebar */}
              <div className="h-[250px] rounded-lg border border-dashed border-border flex items-center justify-center">
                <span className="text-xs text-muted-foreground">Ad Space</span>
              </div>
            </div>
          </aside>
        </div>
      </main>
      <Footer />
    </>
  );
}
