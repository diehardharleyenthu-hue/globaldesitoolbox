import { Metadata } from "next";
import { notFound } from "next/navigation";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { ToolCard } from "@/components/tool-card";
import { Breadcrumbs } from "@/components/breadcrumbs";
import {
  categories,
  getCategoryBySlug,
  getToolsByCategory,
} from "@/lib/tools";

interface CategoryPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  return categories.map((category) => ({
    slug: category.slug,
  }));
}

export async function generateMetadata({
  params,
}: CategoryPageProps): Promise<Metadata> {
  const { slug } = await params;
  const category = getCategoryBySlug(slug);

  if (!category) {
    return { title: "Category Not Found" };
  }

  return {
    title: `${category.name} - Free Online Tools | Global Desi Toolbox`,
    description: category.description,
    openGraph: {
      title: `${category.name} - Global Desi Toolbox`,
      description: category.description,
    },
  };
}

export default async function CategoryPage({ params }: CategoryPageProps) {
  const { slug } = await params;
  const category = getCategoryBySlug(slug);

  if (!category) {
    notFound();
  }

  const categoryTools = getToolsByCategory(slug);
  const Icon = category.icon;

  return (
    <>
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
        <Breadcrumbs
          items={[{ label: category.name }]}
        />

        <section className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
              <Icon className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground md:text-3xl">
                {category.name}
              </h1>
              <p className="text-muted-foreground">{category.description}</p>
            </div>
          </div>
        </section>

        {/* Ad-friendly spacing */}
        <div className="my-8" aria-hidden="true" />

        <section>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {categoryTools.map((tool) => (
              <ToolCard key={tool.slug} tool={tool} showCategory={false} />
            ))}
          </div>
        </section>

        {/* Ad-friendly spacing */}
        <div className="my-10" aria-hidden="true" />

        {/* SEO Text */}
        <section className="rounded-lg border border-border bg-card p-6">
          <h2 className="text-lg font-semibold text-foreground mb-3">
            About {category.name}
          </h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Browse our collection of free {category.name.toLowerCase()}. 
            All tools are designed to be fast, accurate, and easy to use. 
            No registration required - start using any tool instantly.
          </p>
        </section>
      </main>
      <Footer />
    </>
  );
}
