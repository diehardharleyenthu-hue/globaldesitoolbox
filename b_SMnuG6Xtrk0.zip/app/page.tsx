import { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Search } from "lucide-react";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { ToolCard } from "@/components/tool-card";
import { CategoryCard } from "@/components/category-card";
import { tools, categories } from "@/lib/tools";

export const metadata: Metadata = {
  title: "Global Desi Toolbox - Free Finance Calculators & Utility Tools",
  description:
    "Free online calculators and tools: EMI calculator, GST calculator, SIP calculator, currency converter, age calculator, and more. Fast, accurate, no sign-up required.",
  keywords: [
    "EMI calculator",
    "GST calculator",
    "SIP calculator",
    "income tax calculator",
    "currency converter",
    "age calculator",
    "online tools",
    "free calculators",
  ],
  openGraph: {
    title: "Global Desi Toolbox - Free Finance Calculators & Utility Tools",
    description:
      "Free online calculators for EMI, GST, SIP, tax, and more. Fast, accurate, no sign-up.",
    type: "website",
  },
};

export default function HomePage() {
  const popularTools = tools.slice(0, 8);

  return (
    <>
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
        {/* Hero - Minimal */}
        <section className="text-center py-8 md:py-12">
          <h1 className="text-3xl font-bold text-foreground md:text-4xl lg:text-5xl text-balance">
            Free Online Calculators & Tools
          </h1>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Finance calculators, converters, and everyday utilities. 
            Fast, accurate, and completely free.
          </p>
        </section>

        {/* Ad-friendly spacing - natural content break */}
        <div className="my-8" aria-hidden="true" />

        {/* Categories Grid */}
        <section className="mb-12">
          <h2 className="text-xl font-semibold text-foreground mb-6">
            Browse by Category
          </h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {categories.map((category) => (
              <CategoryCard key={category.slug} category={category} />
            ))}
          </div>
        </section>

        {/* Ad-friendly spacing */}
        <div className="my-10" aria-hidden="true" />

        {/* Popular Tools Grid */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-foreground">
              Popular Tools
            </h2>
            <Link
              href="/tools"
              className="flex items-center text-sm font-medium text-primary hover:underline"
            >
              View all tools
              <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {popularTools.map((tool) => (
              <ToolCard key={tool.slug} tool={tool} />
            ))}
          </div>
        </section>

        {/* Ad-friendly spacing */}
        <div className="my-10" aria-hidden="true" />

        {/* All Tools by Category - SEO internal linking */}
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-6">
            All Tools
          </h2>
          <div className="space-y-10">
            {categories.map((category) => {
              const categoryTools = tools.filter(
                (t) => t.categorySlug === category.slug
              );
              return (
                <div key={category.slug}>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-medium text-foreground">
                      {category.name}
                    </h3>
                    <Link
                      href={`/category/${category.slug}`}
                      className="text-sm text-primary hover:underline"
                    >
                      See all
                    </Link>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                    {categoryTools.map((tool) => (
                      <ToolCard
                        key={tool.slug}
                        tool={tool}
                        showCategory={false}
                      />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Ad-friendly spacing */}
        <div className="my-10" aria-hidden="true" />

        {/* SEO Text Block */}
        <section className="rounded-lg border border-border bg-card p-6 md:p-8">
          <h2 className="text-lg font-semibold text-foreground mb-4">
            About Global Desi Toolbox
          </h2>
          <div className="prose prose-sm text-muted-foreground max-w-none">
            <p>
              Global Desi Toolbox provides free online calculators and utility tools 
              designed for the Indian and global desi community. Our tools include 
              EMI calculators for home loans and car loans, GST calculators for 
              businesses, SIP calculators for mutual fund investments, and income 
              tax calculators for both old and new tax regimes.
            </p>
            <p className="mt-4">
              All our tools are completely free to use, require no sign-up, and work 
              instantly in your browser. We prioritize accuracy, speed, and privacy 
              - your calculations are never stored or shared.
            </p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
