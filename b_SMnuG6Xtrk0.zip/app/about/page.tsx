import { Metadata } from "next";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { Breadcrumbs } from "@/components/breadcrumbs";
import { Shield, Zap, Globe, Lock } from "lucide-react";

export const metadata: Metadata = {
  title: "About Us - Global Desi Toolbox",
  description:
    "Learn about Global Desi Toolbox - free online calculators and utility tools for the global desi community.",
};

const features = [
  {
    icon: Zap,
    title: "Fast & Instant",
    description: "All calculations happen instantly in your browser with no waiting.",
  },
  {
    icon: Shield,
    title: "100% Free",
    description: "No subscriptions, no hidden fees, no sign-up required.",
  },
  {
    icon: Lock,
    title: "Privacy First",
    description: "Your data never leaves your browser. We don't track or store your calculations.",
  },
  {
    icon: Globe,
    title: "Always Available",
    description: "Access our tools anytime, anywhere, on any device.",
  },
];

export default function AboutPage() {
  return (
    <>
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
        <Breadcrumbs items={[{ label: "About" }]} />

        <div className="max-w-3xl">
          <h1 className="text-2xl font-bold text-foreground md:text-3xl">
            About Global Desi Toolbox
          </h1>

          <div className="mt-6 space-y-4 text-muted-foreground leading-relaxed">
            <p>
              Global Desi Toolbox is a free collection of online calculators and 
              utility tools designed for the Indian and global desi community. 
              We provide essential financial calculators, unit converters, and 
              everyday utilities that help you make informed decisions.
            </p>
            <p>
              Our mission is simple: provide accurate, fast, and free tools that 
              anyone can use without barriers. No sign-ups, no subscriptions, 
              no tracking - just useful tools that work.
            </p>
          </div>

          {/* Ad-friendly spacing */}
          <div className="my-10" aria-hidden="true" />

          <section className="mt-12">
            <h2 className="text-xl font-semibold text-foreground mb-6">
              Why Use Our Tools
            </h2>
            <div className="grid gap-6 sm:grid-cols-2">
              {features.map((feature) => {
                const Icon = feature.icon;
                return (
                  <div
                    key={feature.title}
                    className="rounded-lg border border-border bg-card p-5"
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <h3 className="mt-4 text-base font-medium text-foreground">
                      {feature.title}
                    </h3>
                    <p className="mt-2 text-sm text-muted-foreground">
                      {feature.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Ad-friendly spacing */}
          <div className="my-10" aria-hidden="true" />

          <section className="mt-12 rounded-lg border border-border bg-card p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">
              Our Commitment
            </h2>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                All tools are free to use forever
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                Regular updates to ensure accuracy
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                Mobile-friendly design for on-the-go use
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                No personal data collection
              </li>
            </ul>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}
