import Link from "next/link";
import { ArrowRight } from "lucide-react";
import type { Tool } from "@/lib/tools";

interface ToolCardProps {
  tool: Tool;
  showCategory?: boolean;
}

export function ToolCard({ tool, showCategory = true }: ToolCardProps) {
  const Icon = tool.icon;
  
  return (
    <Link
      href={`/tools/${tool.slug}`}
      className="group block rounded-lg border border-border bg-card p-5 hover:border-primary/50"
    >
      <div className="flex items-start justify-between">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
          <Icon className="h-5 w-5 text-primary" />
        </div>
        {showCategory && (
          <span className="text-xs text-muted-foreground">{tool.category}</span>
        )}
      </div>
      <h3 className="mt-4 text-base font-semibold text-foreground group-hover:text-primary">
        {tool.title}
      </h3>
      <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
        {tool.shortDescription}
      </p>
      <div className="mt-4 flex items-center text-sm font-medium text-primary">
        Use Tool
        <ArrowRight className="ml-1 h-4 w-4" />
      </div>
    </Link>
  );
}
