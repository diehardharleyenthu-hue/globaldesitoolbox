import Link from "next/link";
import { ArrowRight } from "lucide-react";
import type { Category } from "@/lib/tools";
import { getToolsByCategory } from "@/lib/tools";

interface CategoryCardProps {
  category: Category;
}

export function CategoryCard({ category }: CategoryCardProps) {
  const Icon = category.icon;
  const toolCount = getToolsByCategory(category.slug).length;
  
  return (
    <Link
      href={`/category/${category.slug}`}
      className="group block rounded-lg border border-border bg-card p-6 hover:border-primary/50"
    >
      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
        <Icon className="h-6 w-6 text-primary" />
      </div>
      <h3 className="mt-4 text-lg font-semibold text-foreground group-hover:text-primary">
        {category.name}
      </h3>
      <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
        {category.description}
      </p>
      <div className="mt-4 flex items-center justify-between">
        <span className="text-xs text-muted-foreground">{toolCount} tools</span>
        <span className="flex items-center text-sm font-medium text-primary">
          Browse
          <ArrowRight className="ml-1 h-4 w-4" />
        </span>
      </div>
    </Link>
  );
}
